from pathlib import Path
import os

MASTER_PROFILE = globals().get("MASTER_PROFILE", os.environ.get("OPT_PROFILE", "smoke"))
MASTER_ROOT = Path(globals().get("MASTER_ROOT", os.environ.get("OPT_RESULTS_ROOT", "optimisation_results"))).resolve()
MASTER_INCLUDE_TRANSFER = globals().get("MASTER_INCLUDE_TRANSFER", os.environ.get("OPT_INCLUDE_TRANSFER", "1") == "1")
if MASTER_PROFILE not in ("full", "smoke"):
    raise ValueError("Choose full or smoke.")

import gzip
import hashlib
import json
import math
import random
import zipfile
from dataclasses import dataclass
from math import cos, hypot, sin, tau

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from IPython.display import display
from scipy.linalg import cho_solve, cholesky, solve_triangular
from scipy.optimize import minimize
from scipy.spatial.distance import cdist


JITTER = 1e-7

def rotate(point, angle):
    x, y = point
    return cos(angle) * x - sin(angle) * y, sin(angle) * x + cos(angle) * y

@dataclass(frozen=True)
class Valley:
    centre: tuple
    angle: float
    curvature_ratio: float = 100.0
    bend: float = 0.0

    @property
    def normaliser(self):
        # Under uniform disk sampling E[X^2] = 1/4 and E[X^4] = 1/8.
        # Terms odd in either coordinate integrate to zero.
        a, b = self.centre
        if self.bend == 0:
            k = self.curvature_ratio
            return (1 + k) / 4 + a*a + k*b*b
        eu2 = .25 + a*a
        ev2 = .25 + b*b
        eu4 = .125 + 1.5*a*a + a**4
        return eu2 + self.curvature_ratio * (
            ev2 + 2*self.bend*b*eu2 + self.bend**2*eu4
        )

    def canonical_gap(self, x, y):
        a, b = self.centre
        u, v = x - a, y - b
        return (u**2 + self.curvature_ratio*(v - self.bend*u**2)**2) / self.normaliser

    def clean(self, point):
        if hypot(*point) > 1.0 + 1e-12:
            raise ValueError("Point outside the unit disk")
        x, y = rotate(point, -self.angle)
        return self.canonical_gap(x, y)

    def observe(self, point, sigma, rng):
        return self.clean(point) + sigma * rng.gauss(0.0, 1.0)

def covariance(x, y, theta):
    lengths = np.exp(theta[1:])
    return np.exp(theta[0] - .5 * cdist(x / lengths, y / lengths, "sqeuclidean"))

def fit(x, values, theta, refit, noise_sd=0.0, jitter=JITTER):
    output_scale = values.std() or 1
    y = (values - values.mean()) / output_scale
    ident = np.eye(len(x))

    def factor(parameters):
        signal = covariance(x, x, parameters)
        lower = cholesky(signal + (jitter + (noise_sd/output_scale)**2) * ident, lower=True)
        return signal, lower, cho_solve((lower, True), y)

    def likelihood(parameters):
        signal, lower, alpha = factor(parameters)
        loss = .5 * (y @ alpha) + np.log(np.diag(lower)).sum()
        weights = .5 * (cho_solve((lower, True), ident) - np.outer(alpha, alpha)) * signal
        gradient = [weights.sum()]
        if len(parameters) == 2:
            gradient.append((weights * cdist(x, x, "sqeuclidean")).sum() / np.exp(2*parameters[1]))
        else:
            for axis, log_length in enumerate(parameters[1:]):
                diff = x[:, axis, None] - x[:, axis]
                gradient.append((weights * diff**2).sum() / np.exp(2*log_length))
        return loss, np.array(gradient)

    status = -1
    if refit:
        bounds = [(-6, 6)] + [(math.log(.02), math.log(2))] * (len(theta)-1)
        result = minimize(likelihood, theta, jac=True, bounds=bounds, method="L-BFGS-B",
                          options={"maxiter": 50})
        theta, status = result.x, int(result.status)
    _, lower, alpha = factor(theta)
    return theta, lower, alpha, status

def predict(x, candidates, theta, lower, alpha):
    cross = covariance(x, candidates, theta)
    projected = solve_triangular(lower, cross, lower=True, check_finite=False)
    variance = np.maximum(0, np.exp(theta[0]) - np.einsum("ij,ij->j", projected, projected))
    return cross.T @ alpha, np.sqrt(variance)

SHORTLIST_SIZES = (4, 8, 12)
METHOD = "Isotropic BO"
BASELINE = "LCB throughout"
PREFIX, BUDGET = 72, 96


def simulate_shortlists(clean, mu, cov, scale, sigma, noise, baseline, labels):
    """Both readouts use the same noisy measurements and choose within the shortlist."""
    rows = []
    for size in SHORTLIST_SIZES:
        repeats = (BUDGET - PREFIX) // size
        assert size * repeats == BUDGET - PREFIX
        gaps = clean[:size]
        fresh = gaps + sigma * noise[:, :size, :repeats].mean(axis=2)
        # mu is in original gap units. cov is in standardised units.
        # Condition the prefix GP on independent sample means with variance sigma²/r.
        if sigma > 0:
            prior_cov = cov[:size, :size]
            observation_cov = prior_cov + ((sigma / scale) ** 2 / repeats) * np.eye(size)
            factor = cholesky(observation_cov, lower=True)
            weights = cho_solve((factor, True), prior_cov)
            gp_scores = mu[:size] + (fresh - mu[:size]) @ weights
        else:
            gp_scores = fresh  # the clean repeat directly reveals every finalist's value
        for rule, scores in (("Fresh means", fresh), ("Updated GP", gp_scores)):
            chosen = gaps[scores.argmin(axis=1)]
            oracle_gap = float(gaps.min())
            rows.append(dict(**labels, shortlist_size=size, repeats_per_finalist=repeats,
                             rule=rule, prefix_best=float(clean.min()), shortlist_best=oracle_gap,
                             shortlist_loss=oracle_gap - float(clean.min()),
                             finalist_ranking_loss=float((chosen - oracle_gap).mean()),
                             recommendation=float(chosen.mean()),
                             delta_vs_lcb=float((chosen - baseline).mean()),
                             probability_beating_lcb=float((chosen < baseline).mean()),
                             mc_se_recommendation=float(chosen.std(ddof=1) / np.sqrt(len(chosen)))))
    return rows


def analyse_blocks(settings, read, draws_per_block):
    oracle_rows, simulations = [], []
    for seed in settings["seeds"]:
        block = json.loads(gzip.decompress(read(f"blocks/{seed}.json.gz")))
        prefixes = {(row["problem"], row["sigma"]): row for row in block["prefixes"]
                    if row["method"] == METHOD and row["scope"] == "Main valleys"}
        if len(prefixes) != 4 * len(settings["noise"]):
            raise ValueError(f"Seed {seed} is missing main-valley prefix records.")
        noise = np.random.default_rng(np.random.SeedSequence([seed, 58101])).standard_normal(
            (draws_per_block, max(SHORTLIST_SIZES), 6))
        centre = rotate((.4, 0), random.Random(seed).uniform(0, tau))
        histories = [h for h in block["histories"]
                     if h["method"] == METHOD and h["policy"] == BASELINE
                     and h["scope"] == "Main valleys"]
        if len(histories) != len(prefixes):
            raise ValueError(f"Seed {seed} is missing continued LCB histories.")
        for h in histories:
            problem, sigma = h["problem"], h["sigma"]
            diagnostic = prefixes[problem, sigma]
            assert h["seed"] == diagnostic["seed"] == seed and len(h["trace"]) == BUDGET
            labels = dict(seed=seed, problem=problem, sigma=sigma)
            baseline = diagnostic["continued_recommendation"]
            trace = h["trace"][:PREFIX]
            x = np.array([r["point"] for r in trace])
            y = np.array([r["observed"] for r in trace])
            # The policy records the fitted hyperparameters used to choose call 73.
            # Using them reproduces the GP at the 72-call branch boundary.
            theta = np.array(next(d["theta"] for d in h["decisions"] if d["call"] == PREFIX + 1))
            _, lower, alpha, _ = fit(x, y, theta, False, noise_sd=sigma, jitter=settings["jitter"])
            assert len(np.unique(x, axis=0)) == PREFIX
            scale = y.std() or 1.
            posterior, _ = predict(x, x, theta, lower, alpha)
            order = np.argsort(posterior, kind="stable")
            objective = Valley(centre, math.radians(h["angle"]), 100, h["bend"])
            clean = np.array([objective.clean(p) for p in x[order]])
            np.testing.assert_allclose(clean.min(), diagnostic["prefix_best_visited"], atol=1e-12, rtol=1e-8)
            # A replay can break numerical near ties differently on another platform.
            # Keep the original oracle table separate from the reconstructed shortlists.
            oracle_rows.append(dict(**labels, continued_recommendation=baseline,
                                    prefix_best=diagnostic["prefix_best_visited"],
                                    selection_loss=diagnostic["prefix_selection_loss"],
                                    shortlist_loss=diagnostic["shortlist_loss"],
                                    all_points_can_beat_lcb=diagnostic["oracle_can_strictly_improve"],
                                    top_four_can_beat_lcb=diagnostic["oracle_advantage"] > diagnostic["shortlist_loss"],
                                    replay_top_four_loss_delta=clean[:4].min() - clean.min() - diagnostic["shortlist_loss"],
                                    replay_leader_loss_delta=clean[0] - clean.min() - diagnostic["prefix_selection_loss"]))
            candidates = x[order[:max(SHORTLIST_SIZES)]]
            projected = solve_triangular(lower, covariance(x, candidates, theta), lower=True,
                                         check_finite=False)
            cov = covariance(candidates, candidates, theta) - projected.T @ projected
            cov = (cov + cov.T) / 2
            simulations.extend(simulate_shortlists(clean, posterior[order] * scale + y.mean(),
                                                   cov, scale, sigma, noise, baseline, labels))
    return pd.DataFrame(oracle_rows), pd.DataFrame(simulations)


def paired_summary(results, seeds):
    """Average within blocks first. Monte Carlo draws are not independent search runs."""
    bootstrap = np.random.default_rng(58102).integers(0, len(seeds), (10000, len(seeds)))
    rows = []
    for (problem, sigma), group in results.groupby(["problem", "sigma"], sort=True):
        by_policy = group.pivot(index="seed", columns=["rule", "shortlist_size"],
                                values="recommendation").reindex(seeds)
        assert not by_policy.isna().any().any()
        comparisons = []
        for rule in ("Fresh means", "Updated GP"):
            for size in SHORTLIST_SIZES:
                comparisons.append((f"{rule}, K={size} vs LCB",
                                    group[(group.rule == rule) & (group.shortlist_size == size)]
                                    .set_index("seed").reindex(seeds).delta_vs_lcb.to_numpy()))
                if size != 4:
                    comparisons.append((f"{rule}, K={size} vs K=4",
                                        (by_policy[rule, size] - by_policy[rule, 4]).to_numpy()))
        for size in SHORTLIST_SIZES:
            comparisons.append((f"Updated GP vs fresh means, K={size}",
                                (by_policy["Updated GP", size] - by_policy["Fresh means", size]).to_numpy()))
        for label, delta in comparisons:
            lo, hi = np.quantile(delta[bootstrap].mean(axis=1), [.025, .975]) if len(seeds) > 2 else (np.nan, np.nan)
            rows.append(dict(problem=problem, sigma=sigma, contrast=label, n=len(seeds),
                             mean_delta=delta.mean(), low_95=lo, high_95=hi))
    return pd.DataFrame(rows)


def save_results(oracle, results, settings, output):
    summary = oracle.groupby(["problem", "sigma"], as_index=False).agg(
        blocks=("seed", "size"), all_points_wins=("all_points_can_beat_lcb", "sum"),
        top_four_wins=("top_four_can_beat_lcb", "sum"),
        mean_shortlist_loss=("shortlist_loss", "mean"), mean_selection_loss=("selection_loss", "mean"))
    summary["share_of_mean_selection_loss"] = summary.mean_shortlist_loss / summary.mean_selection_loss
    metrics = ["prefix_best", "shortlist_best", "shortlist_loss", "finalist_ranking_loss",
               "recommendation", "delta_vs_lcb", "probability_beating_lcb", "mc_se_recommendation"]
    grouped = results.groupby(["problem", "sigma", "shortlist_size", "rule"], as_index=False)[metrics].mean()
    np.testing.assert_allclose(grouped.recommendation,
                               grouped.prefix_best + grouped.shortlist_loss + grouped.finalist_ranking_loss)
    output.mkdir(parents=True, exist_ok=True)
    for name, table in (("oracle_by_seed", oracle), ("cross_valley_oracle", summary),
                        ("verification_by_seed", results), ("verification_summary", grouped),
                        ("verification_paired_effects", paired_summary(results, settings["seeds"]))):
        table.to_csv(output / f"{name}.csv", index=False)

    high_noise = grouped[grouped.sigma == .01]
    display(summary[summary.sigma == .01])
    display(high_noise[["problem", "shortlist_size", "rule", "shortlist_loss",
                        "finalist_ranking_loss", "delta_vs_lcb", "probability_beating_lcb"]])
    fig, axes = plt.subplots(2, 2, figsize=(10, 6), layout="constrained")
    for ax, (problem, panel) in zip(axes.flat, high_noise.groupby("problem")):
        for rule, curve in panel.groupby("rule"):
            ax.plot(curve.shortlist_size, curve.delta_vs_lcb, marker="o", label=rule)
        shortlist = panel[panel.rule == "Fresh means"]
        ax.plot(shortlist.shortlist_size,
                shortlist.delta_vs_lcb - shortlist.finalist_ranking_loss,
                marker="o", linestyle=":", label="Shortlist oracle")
        ax.axhline(0, color="0.5", linewidth=1)
        ax.set(title=problem, xlabel="Shortlist size", ylabel="Mean gap change vs LCB",
               xticks=SHORTLIST_SIZES)
    axes[0, 0].legend()
    fig.suptitle("72 search calls + 24 verification calls | noise SD 0.01")
    fig.savefig(output / "verification_high_noise.png", dpi=160)
    plt.show()
    plt.close(fig)


def run(read, source_label):
    settings = json.loads(read("settings.json"))
    source_hash = hashlib.sha256(read("experiment.py")).hexdigest()
    expected_seeds = list(range(10100, 10124 if MASTER_PROFILE == "full" else 10102))
    if (settings["profile"] != MASTER_PROFILE or settings["seeds"] != expected_seeds
            or settings["prefix"] != PREFIX or settings["budget"] != BUDGET
            or source_hash != settings["source_sha256"]):
        raise ValueError("Use a complete Stage C mechanisms archive for the selected profile.")
    draws_per_block = 4096 if MASTER_PROFILE == "full" else 128
    output = MASTER_ROOT / "shortlist" / MASTER_PROFILE
    oracle, simulations = analyse_blocks(settings, read, draws_per_block)
    changed = oracle[np.abs(oracle.replay_top_four_loss_delta) > 1e-12]
    print(f"Reconstructed shortlist oracle differed from the saved one in {len(changed)} "
          f"of {len(oracle)} seed conditions.")
    if len(changed):
        display(changed[["seed", "problem", "sigma", "replay_top_four_loss_delta"]])
    save_results(oracle, simulations, settings, output)
    (output / "analysis_settings.json").write_text(json.dumps(
        dict(source=source_label, source_sha256=source_hash, seeds=settings["seeds"],
             shortlist_sizes=SHORTLIST_SIZES, simulations_per_seed_condition=draws_per_block,
             prefix_calls=PREFIX, total_calls=BUDGET), indent=2), encoding="utf-8")
    print("Saved shortlist results:", output)


source = MASTER_ROOT / "stage_c_mechanisms" / MASTER_PROFILE
archive = Path(globals().get("MASTER_SHORTLIST_ARCHIVE", "optimisation_results_full.zip"))
if (source / "settings.json").is_file():
    run(lambda name: (source / name).read_bytes(), str(source))
elif archive.is_file():
    with zipfile.ZipFile(archive) as bundle:
        base = f"results/stage_c_mechanisms/{MASTER_PROFILE}/"
        run(lambda name: bundle.read(base + name), str(archive))
else:
    raise FileNotFoundError(f"Place the completed results ZIP at {archive}, or run the mechanisms stage.")
