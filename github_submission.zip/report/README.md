# Report source

Replace the GitHub repository placeholder near the start of main.tex.
In Overleaf, select main.tex as the main document and compile with pdfLaTeX.
Locally, run latexmk -pdf main.tex from this folder. The bibliography uses BibTeX.

## Reproduce the new analysis

Extract optimisation_results_full.zip, then from this folder run:

    python analyse_report.py <extracted-folder>/results/stage_c_mechanisms/full

The script uses the Python standard library. It verifies the experiment source
hash, the block inventory, budgets, shared BO histories, and the decomposition
of every recommendation gap. It recomputes the report's paired intervals,
oracle counts, parent ranking comparison, and the two cross-function contrasts.
The new analysis uses its own fixed bootstrap seed, so bootstrap endpoints can
differ slightly from the notebook's displayed endpoints.

Use noisy_optimisation_master_shortlist.ipynb, PROFILE = "full", and
INCLUDE_SUPPORTING_TRANSFER = True. Use RUN_MODE = "report" to reproduce
the main stages, or RUN_MODE = "new" for the fresh runs and shortlist
follow-up. Use RUN_MODE = "shortlist" with SHORTLIST_ARCHIVE pointing to
optimisation_results_full.zip to repeat just the shortlist follow-up.
Read cross_valley_oracle.csv, verification_summary.csv and
verification_paired_effects.csv under results/shortlist/full in the
follow-up ZIP for the corresponding report numbers.

For the earlier transfer sample, use RUN_MODE = "custom" and
CUSTOM_STAGES = ["transfer_original"]. Stage A and Stage B figures
are included in figures/.
