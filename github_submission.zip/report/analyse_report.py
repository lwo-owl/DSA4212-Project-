"""Reproduce the new report statistics from the full Colab results.

Usage: python analyse_report.py path/to/stage_c_mechanisms/full
"""
import argparse
import csv
import gzip
import hashlib
import json
import math
import random
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, median, quantiles


def main(root):
    settings = json.loads((root / "settings.json").read_text(encoding="utf-8"))
    seeds = settings["seeds"]
    assert seeds == list(range(10100, 10124))
    assert hashlib.sha256((root / "experiment.py").read_bytes()).hexdigest() == settings["source_sha256"]
    assert {int(p.name.split(".")[0]) for p in (root / "blocks").glob("*.json.gz")} == set(seeds)
    groups = defaultdict(dict)
    prefixes = defaultdict(dict)
    parents = defaultdict(dict)
    for seed in seeds:
        with gzip.open(root / "blocks" / f"{seed}.json.gz", "rt", encoding="utf-8") as stream:
            block = json.load(stream)
        assert len(block["results"]) == 162 and len(block["prefixes"]) == 54
        assert len(block["histories"]) == 126
        histories = defaultdict(dict)
        for h in block["histories"]:
            assert h["seed"] == seed and len(h["trace"]) == 96
            histories[h["problem"], h["sigma"], h["method"]][h["policy"]] = h["trace"]
        for condition, policies in histories.items():
            if condition[-1] == "Isotropic BO":
                assert len(policies) == 5
                assert all(t[:72] == policies["LCB throughout"][:72] for t in policies.values())
        for row in block["results"]:
            assert row["seed"] == seed and row["search_calls"] + row["repeat_calls"] == 96
            assert math.isclose(row["recommendation"], row["best_visited"] + row["selection_loss"], abs_tol=1e-12)
            key = tuple(row[field] for field in ("problem", "sigma", "method", "policy", "readout"))
            assert seed not in groups[key]
            groups[key][seed] = row
        for row in block["prefixes"]:
            key = tuple(row[field] for field in ("problem", "sigma", "method", "readout"))
            assert seed not in prefixes[key]
            prefixes[key][seed] = row
        for row in block["parents"]:
            if 9 <= row["generation"] <= 14:
                key = (row["problem"], row["sigma"], row["policy"], row["generation"])
                assert seed not in parents[key]
                parents[key][seed] = row
    assert len(groups) == 162 and all(list(g) == seeds for g in groups.values())
    assert len(prefixes) == 54 and all(list(g) == seeds for g in prefixes.values())
    with (root / "run_gaps.csv").open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 3888
    for row in rows:
        key = (row["problem"], float(row["sigma"]), row["method"], row["policy"], row["readout"])
        saved = groups[key][int(row["seed"])]
        for field in ("recommendation", "best_visited", "selection_loss"):
            assert float(row[field]) == saved[field]

    # A bootstrap draw resamples complete seed blocks, including all functions,
    # policies and noise conditions. Interactions are contrasts within blocks.
    rng = random.Random(20261111)
    draws = [Counter(rng.choices(range(len(seeds)), k=len(seeds))) for _ in range(10000)]
    gp, native = "GP reranking", "Lowest observed/averaged score"
    bo, cma = "Isotropic BO", "CMA-ES"
    curved = "Curved 45 deg"
    comparisons = [
        (bo, "KG unrestricted", gp, "LCB throughout", gp),
        (bo, "KG new only", gp, "LCB throughout", gp),
        (bo, "KG repeats only", gp, "LCB throughout", gp),
        (bo, "KG unrestricted", gp, "KG new only", gp),
        (bo, "Alternating 12 + 12", gp, "LCB throughout", gp),
        (cma, "Standard", gp, "Standard", native),
        (cma, "Cutoff repeats", gp, "Cutoff repeats", native),
        (cma, "Cutoff repeats", gp, "Standard", gp),
    ]

    def interval(values, level=.95):
        distribution = sorted(sum(values[i] * count for i, count in draw.items()) / len(seeds)
                              for draw in draws)
        tail = (1 - level) / 2
        return (mean(values), distribution[round(tail * (len(draws) - 1))],
                distribution[round((1 - tail) * (len(draws) - 1))])

    def display(values, level=.95, ratio=False):
        estimates = interval(values, level)
        return " ".join(f"{10 ** v if ratio else v:.6g}" for v in estimates)

    def paired(problem, sigma, comparison, metric):
        method, a, readout_a, b, readout_b = comparisons[comparison]
        ga = groups[problem, sigma, method, a, readout_a]
        gb = groups[problem, sigma, method, b, readout_b]
        if metric == "log":
            return [math.log10(max(ga[s]["recommendation"], 1e-14)) -
                    math.log10(max(gb[s]["recommendation"], 1e-14)) for s in seeds]
        return [ga[s][metric] - gb[s][metric] for s in seeds]

    for problem in (curved, "BBOB f14", "BBOB f15"):
        for sigma in (0., .001, .01):
            print(f"\n{problem}, noise {sigma:g}")
            for i, (_, a, ra, b, rb) in enumerate(comparisons):
                effect = paired(problem, sigma, i, "log")
                raw = [paired(problem, sigma, i, m)
                       for m in ("recommendation", "best_visited", "selection_loss")]
                assert all(math.isclose(r, s + l, abs_tol=1e-12) for r, s, l in zip(*raw))
                print(f"{i} {a}/{ra} vs {b}/{rb}: {display(effect, ratio=True)};"
                      f" raw R/S/L {', '.join(display(v) for v in raw)}")
            for method, readout in ((bo, gp), (cma, native), (cma, gp)):
                rows = list(prefixes[problem, sigma, method, readout].values())
                print(method, readout, "all-points oracle", sum(r["oracle_can_strictly_improve"] for r in rows),
                      "four-finalist oracle", sum(r["oracle_advantage"] > r["shortlist_loss"] for r in rows))
                for field in ("prefix_best_visited", "prefix_selection_loss", "shortlist_loss",
                              "remaining_search_gain", "oracle_advantage", "shortlist_margin_over_noise"):
                    values = [r[field] for r in rows if r[field] is not None]
                    if values:
                        print(field, display(values), "median", f"{median(values):.6g}")
                if sigma:
                    for repeats in (1, 6):
                        costs = [r["shortlist_best_second_margin"] * r[f"fresh_pair_error_{repeats}"]
                                 for r in rows]
                        print(f"Expected loss comparing clean best two with {repeats} fresh calls each",
                              f"{mean(costs):.6g}")
            kg = groups[problem, sigma, bo, "KG unrestricted", gp]
            print("KG repeat calls mean/median", mean(r["repeat_calls"] for r in kg.values()),
                  median(r["repeat_calls"] for r in kg.values()))

    print("\nCross-function contrasts, sigma 0.01, KG unrestricted vs LCB")
    reference = paired(curved, .01, 0, "log")
    for other in ("BBOB f14", "BBOB f15"):
        effect = [b - a for a, b in zip(reference, paired(other, .01, 0, "log"))]
        print(other, "ratio of ratios; 95%; Bonferroni 97.5%:", display(effect, ratio=True),
              display(effect, level=.975, ratio=True))
    print("Primary ratio, 90% interval for illustrative 0.80--1.25 similarity range:",
          display(paired(curved, .01, 3, "log"), level=.90, ratio=True))
    print("\nCMA parents at matched generations 9--14, curved 45, sigma 0.01")
    standard = [mean(parents[curved, .01, "Standard", g][s]["parent_error"] for g in range(9, 15))
                for s in seeds]
    cutoff = [mean(parents[curved, .01, "Cutoff repeats", g][s]["parent_error"] for g in range(9, 15))
              for s in seeds]
    print("Standard, cutoff, paired difference", mean(standard), mean(cutoff),
          display([b-a for a, b in zip(standard, cutoff)]))
    print("Standard, cutoff mean search calls", *[
        mean(r["search_calls"] for r in groups[curved, .01, cma, policy, gp].values())
        for policy in ("Standard", "Cutoff repeats")])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    main(parser.parse_args().results)

